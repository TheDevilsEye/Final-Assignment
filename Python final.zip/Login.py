import Employee_Sys
from tkinter import *
import os
from tkinter import messagebox
"""The def delete2,3 and 4 function destroys the screen"""

def delete2():
    screen3.destroy()
    employee()

def delete3():
    screen4.destroy()


def delete4():
    screen5.destroy()
"""The def login_success function is executed if the login username and password is correct"""

def login_success():
    global screen3
    screen3 = Toplevel(screen)
    screen3.title("Login Success")
    screen3.geometry("150x50")
    screen3.resizable(0, 0)
    Label(screen3, text="Login is Successful").pack()
    Button(screen3, text="OK", bg="black", fg="red", command=delete2).pack()

"""The def  password_not_recognised function is executed if the entered password is incorrect """
def password_not_recognised():
    global screen4
    screen4 = Toplevel(screen)
    screen4.title("Error")
    screen4.geometry("300x300")
    screen4.resizable(0, 0)
    Label(screen4, text="Password Error").pack()
    Button(screen4, text="OK", bg="black", fg="red", command=delete3).pack()

"""The def user_not_found is executed if the registered user is different from the username in login"""
def user_not_found():
    global screen5
    screen5 = Toplevel(screen)
    screen5.title("Error")
    screen5.geometry("300x300")
    Label(screen5, text="User Not Found").pack()
    Button(screen5, text="OK", command=delete4).pack()

"""The def register_user is executed at the time of registration"""
def register_user():
    print("working")

    username_info = username.get()
    password_info = password.get()
    j = os.listdir()

    if username_info+'.txt' in j:
        messagebox.showerror('Failed', 'username already exists')

    else:
        file = open(username_info + '.txt', "w")
        file.write(username_info + "\n")
        file.write(password_info)
        file.close()
        messagebox.showinfo('Success', 'Registered Successfully ')
    username_entry.delete(0, END)
    password_entry.delete(0, END)

    screen1.withdraw()

"""The def login_verify is executed at the time of login to verify the registered user"""
def login_verify():
    username_info = username_verify.get()
    password1 = password_verify.get()
    username_entry1.delete(0, END)
    password_entry1.delete(0, END)

    list_of_files = os.listdir()
    if (username_info + '.txt') in list_of_files:
        file1 = open(username_info + '.txt', "r")
        verify = file1.read().splitlines()
        if password1 in verify:
            login_success()

        else:
            password_not_recognised()

    else:
        user_not_found()


"""This function opens a employee window"""
def employee():
    screen2.withdraw()
    screen.withdraw()
    use = Toplevel(screen2)
    Employee_Sys.Employee_sys(use)

"""This function is used to design the register screen"""
def register():
    global screen1
    screen1 = Toplevel(screen)
    screen1.config(background="light cyan")
    screen1.title("Register")
    screen1.geometry("300x300")
    screen1.resizable(0, 0)

    global username
    global password
    global username_entry
    global password_entry
    username = StringVar()
    password = StringVar()

    Label(screen1, text="Please enter details", bg="light cyan").pack()
    Label(screen1, text="", bg="light cyan").pack()
    Label(screen1, text="Username * ", bg="light cyan").pack()

    username_entry = Entry(screen1, textvariable=username)
    username_entry.pack()
    Label(screen1, text="Password * ", bg="light cyan").pack()
    password_entry = Entry(screen1, textvariable=password)
    password_entry.pack()
    Label(screen1, text="", bg="light cyan").pack()
    Button(screen1, text="Register", width=10, height=1, bg="light cyan", command=register_user).pack()

"""This function is used to design the login window"""
def login():
    global screen2
    screen2 = Toplevel(screen)
    screen2.title("Login")
    screen2.config(background="light cyan")
    screen2.geometry("300x300")
    screen2.resizable(0, 0)
    Label(screen2, text="Please enter details to login", bg="light cyan").pack()
    Label(screen2, text="", bg="light cyan").pack()

    global username_verify
    global password_verify

    username_verify = StringVar()
    password_verify = StringVar()

    global username_entry1
    global password_entry1

    Label(screen2, text="Username * ", bg="light cyan").pack()
    username_entry1 = Entry(screen2, textvariable=username_verify)
    username_entry1.pack()
    Label(screen2, text="", bg="light cyan").pack()
    Label(screen2, text="Password * ", bg="light cyan").pack()
    password_entry1 = Entry(screen2, textvariable=password_verify)
    password_entry1.pack()
    Label(screen2, text="", bg="light cyan").pack()
    Button(screen2, text="Login", width=10, height=1, bg="light cyan", command=login_verify).pack()

"""This function is used to design the main screen"""
def main_screen():
    global screen
    screen = Tk()
    screen.config(background="light cyan")
    screen.geometry("300x300")
    screen.resizable(0, 0)
    screen.title("Employ Login/Register")
    Label(text="Welcome to Employ Login/Register", bg="light cyan", width="250", height="3", font=("Aerial", 13)).pack()
    Label(text="", bg="light cyan").pack()
    Button(text="Login", height="3", width="40", bg="blue2", fg="red", command=login).pack()
    Label(text="", bg="light cyan").pack()
    Button(text="Register", height="3", width="40", bg="blue2", fg="red", command=register).pack()

    screen.mainloop()


main_screen()
