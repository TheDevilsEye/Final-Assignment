from tkinter import*
import View_Employee
import Add_Depart
import Add_Emp

"""This class creates employee, department and view employee form"""
class Employee_sys:
    def __init__(self, window):
        self.wn= window
        self.wn.title('Employee system')
        self.wn.geometry('400x300')
        self.wn.config(bg='light cyan')
        self.lb_heading = Label(self.wn, text='Emlpoyee Management System', font=('times new roman', 18, 'bold'), bg='#000014',
                                fg='#f5f5f5')
        self.lb_heading.place(x=0, y=0, relwidth=1)

        #===============Entry and Label

        self.lb_employee_form = Button(self.wn, text='Employee Form', font=('times new roman', 12, 'bold'), command=self.employee_Form,fg='#f5f5f5',
                                 bg='#1829aa', width='25')
        self.lb_employee_form.place(x=80, y=80)

        self.lb_department_form = Button(self.wn, text='Department Form', font=('times new roman', 12, 'bold'), fg='#f5f5f5',
                                 bg='#1829aa',width='25',command=self.add_department_Form)
        self.lb_department_form.place(x=80, y=150)
        self.lb_view_Form = Button(self.wn, text='View Employee', font=('times new roman', 12, 'bold'), command=self.view_Form,fg='#f5f5f5',
                                 bg='#1829aa', width='25')
        self.lb_view_Form.place(x=80, y=220)

    def employee_Form(self):
        """This function opens the imported employee form"""
        emq = Toplevel(self.wn)
        Add_Emp.add_employee(emq)


    def add_department_Form(self):
        """This function opens the imported add department form"""
        add_dep = Toplevel(self.wn)
        Add_Depart.add_Department(add_dep)

    def view_Form(self):
        """This function opens the imported view form"""
        abc = Toplevel(self.wn)
        View_Employee.view_employee(abc)
