from tkinter import *
import Employee_Sys
import pickle
import os
from tkinter import messagebox
"""This class is used to design add department form"""
class add_Department:
    def __init__(self, window):
        self.wn = window
        self.wn.resizable(0, 0)
        self.wn.title('Employee Management System')
        self.wn.config(bg='light cyan')
        self.wn.geometry("450x300")
        self.Lis = []

        self.Department_ID = StringVar()
        self.dep_name = StringVar()
        self.Department_ID1 = IntVar()
        self.dep_name1 = IntVar()
        self.lb1 = Label(self.wn, text='Department form', bg='#000014',
                         fg='#f5f5f5', font=("bold", 20)).pack(fill=X)
        self.en1 = Entry(self.wn, textvariable=self.Department_ID)
        self.en1.place(x=250, y=85)
        self.en2 = Entry(self.wn, textvariable=self.dep_name)
        self.en2.place(x=250, y=145)
        self.Ch1 = Label(self.wn, text="Department ID:", font=('bold', 15), fg='black',
                                 bg='light cyan').place(x=40, y=80)
        self.Ch2 = Label(self.wn, text="Department Name:", font=('bold', 15),fg='black',
                                 bg='light cyan').place(x=40, y=140)
        self.bt1 = Button(self.wn, text='<--Back', width=7, height=1, command=self.yer, fg='#f5f5f5',
                          bg='#1829aa').place(
            x=70, y=210)
        self.bt2 = Button(self.wn, text='Reset', width=7, height=1, command=self.ret, fg='#f5f5f5',
                          bg='#1829aa').place(
            x=170, y=209)
        self.bt3 = Button(self.wn, text='Add', width=7, height=1, command=self.adddd,fg='#f5f5f5',
                          bg='#1829aa').place(
            x=270, y=207)

    def ret(self):

        self.en1.delete(0, END)
        self.en2.delete(0, END)


    def adddd(self):

        Di = self.Department_ID.get()
        Dn = self.dep_name.get()

        if not Di or not Dn:
            messagebox.showerror('Failed', 'All Field Required')
        else:
            self.Dep_Nam = []
            if os.path.exists('d.txt'):
                with open('d.txt', 'rb') as D:
                    self.Dep_Nam = pickle.load(D)
            self.Dep_Nam.append([Dn, Di])

            with open('d.txt', 'wb') as file1:

                pickle.dump(self.Dep_Nam, file1)
            messagebox.showinfo('Success', 'Successfully Added')

    def yer(self):
        self.wn.withdraw()


